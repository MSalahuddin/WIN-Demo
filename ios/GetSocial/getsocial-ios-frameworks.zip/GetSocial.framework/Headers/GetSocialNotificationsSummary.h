//
//
// Copyright (c) 2019 GetSocial BV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetSocialNotificationsSummary : NSObject

@property (nonatomic, readonly) int successfullySentCount;

@end

